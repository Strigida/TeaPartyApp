function initPlatform (startingX, startingY, width, height) {
	var platform = {};

	platform.x = startingX;
	platform.y = startingY;
    platform.height = height;
	platform.width = width;
  return platform;
}
